# Pasang ikon RYTHM sebagai ikon peluncur app Android (dijalankan oleh GitHub Actions).
import os, glob
from PIL import Image

RES = 'android/app/src/main/res'
DENS = {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}
std = Image.open('public/icon-512.png').convert('RGBA')
mask = Image.open('public/icon-maskable.png').convert('RGBA')

# buang ikon bawaan Capacitor yang berformat webp supaya tidak bentrok
for f in glob.glob(f'{RES}/mipmap-*/ic_launcher*.webp'):
    os.remove(f)

for d, m in DENS.items():
    folder = f'{RES}/mipmap-{d}'
    os.makedirs(folder, exist_ok=True)
    s = round(48 * m)
    for name in ('ic_launcher.png', 'ic_launcher_round.png'):
        std.resize((s, s), Image.LANCZOS).save(f'{folder}/{name}')
    f = round(108 * m)
    mask.resize((f, f), Image.LANCZOS).save(f'{folder}/ic_launcher_foreground.png')

# ikon adaptif Android 8+: latar hitam + gambar maskable
os.makedirs(f'{RES}/mipmap-anydpi-v26', exist_ok=True)
adaptive = '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/rythm_icon_bg"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
'''
for name in ('ic_launcher.xml', 'ic_launcher_round.xml'):
    open(f'{RES}/mipmap-anydpi-v26/{name}', 'w').write(adaptive)

os.makedirs(f'{RES}/values', exist_ok=True)
open(f'{RES}/values/rythm_icon_bg.xml', 'w').write(
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="rythm_icon_bg">#000000</color>\n</resources>\n')
print('ikon terpasang')
